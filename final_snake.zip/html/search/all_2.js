var searchData=
[
  ['read_5fcmd',['read_cmd',['../classSnakeModel.html#abb8724466420b3eb43956212ed14a946',1,'SnakeModel']]]
];
