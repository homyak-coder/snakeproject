var searchData=
[
  ['not_5ffinished',['not_finished',['../classSnakeModel.html#a209028a448f9035d431a2adf239af3c8',1,'SnakeModel']]]
];
