#include "snake_model.hpp"
#include "snake_view.hpp"
#include "snake_controller.hpp"
#include "snake_bot.hpp"
/**
 * @brief вспомогательный файл, чтобы не было 4 инклудов в мэйнах
 */
